const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const db = require("../config/db");

// Render halaman register (GET)
router.get("/register", (req, res) => {
  res.render("register");
});

// Proses register user (POST)
router.post("/register", async (req, res) => {
  const { username, email, password } = req.body;

  // Hash password
  const hashedPassword = bcrypt.hashSync(password, 10);

  const query =
    "INSERT INTO admin (username, email, password) VALUES (?, ?, ?)";
  db.query(query, [username, email, hashedPassword], (err) => {
    if (err) {
      console.error(err);
      return res.send("Error registering user");
    }
    req.session.user = { username, email };
    res.redirect("/auth/profile");
  });
});

// Render halaman login (GET)
router.get("/login", (req, res) => {
  res.render("login");
});

// Proses login user (POST)
router.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.send("Both fields are required");
  }

  const query = "SELECT * FROM admin WHERE username = ?";
  db.query(query, [username], (err, result) => {
    if (err) {
      console.error(err);
      return res.send("Database error");
    }
    if (result.length > 0) {
      const user = result[0];
      if (bcrypt.compareSync(password, user.password)) {
        req.session.user = user;
        res.redirect("/auth/profile");
      } else {
        res.send("Incorrect password");
      }
    } else {
      res.send("User not found");
    }
  });
});

// Render halaman profil user (GET)
router.get("/profile", (req, res) => {
  if (req.session.user) {
    res.render("profile", { user: req.session.user });
  } else {
    res.redirect("/auth/login");
  }
});

// Proses logout (GET)
router.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.send("Failed to log out");
    }
    res.redirect("/auth/login");
  });
});

module.exports = router;